<?php


 include('conection.php');

    //coneccion en la base de datos y creacion de variables para la inserccion 

    if (isset($_POST['save'])) {
    
    
    
    echo 'se ha conectado';

    $id = $_POST['id'];

    $numeroEmpleado = $_POST['Numero_Empleado'];

    $nombre = $_POST['Nombre'];

    $primerApellido = $_POST['PrimerApellido'];

    $segundoApellido = $_POST['SegundoApellido'];
    
    $area = $_POST['Area'];

    $puesto = $_POST['Puesto'];

    $nacimiento = $_POST['Nacimiento'];

    //Insertar datos en la base de datos
    $query = "INSERT INTO personal(id ,NumeroEmpleado, Nombre, PrimerApellido, SegundoApellido, Area, Puesto, Nacimiento) VALUE($id ,'$numeroEmpleado', '$nombre', '$primerApellido', '$segundoApellido', '$area', '$puesto', '$nacimiento')";
    
    $result = mysqli_query($conn, $query);

        
    //Verificacion de inserccion de datos
    if(!$result) {

        die("Query Failed");

    }

    $_SESSION['message'] = 'Datos Guardado Con Éxito';

    $_SESSION['message_type'] = 'success';

    header("Location: index.php");

    }else {echo 'error';}





?>
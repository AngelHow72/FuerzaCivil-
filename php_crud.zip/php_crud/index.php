<?php
include("conection.php");
include("includes/Header.php");

?>


<div class="container p-4">


    <div class="row">

        <div class="col-md-4">


            <?php if (isset($_SESSION['message'])) { ?>

                <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
                    <?= $_SESSION['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

            <?php session_unset();
            } ?>

            <div class="card card-body">

                <form action="save.php" method="POST">


                <div class="form-group">
                        <input type="text" name="id" class="form-control" placeholder="Poner un id que no sea repetido" autofocus>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="Numero_Empleado" class="form-control" placeholder="Numero Empleado" autofocus>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="Nombre" class="form-control" placeholder="Nombre" autofocus>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="PrimerApellido" class="form-control" placeholder="Apellido Paterno" autofocus>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="SegundoApellido" class="form-control" placeholder="Apellido Materno" autofocus>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="Area" class="form-control" placeholder="Area / Departamento" autofocus>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="text" name="Puesto" class="form-control" placeholder="Puesto" autofocus>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="Date" name="Nacimiento" class="form-control" placeholder="Fecha de Nacimiento" autofocus>
                    </div>
                    <br>
                    <input type="submit" class="btn btn-success btn-block" name="save" value="Guardar Datos">


                </form>

            </div>

        </div>


        <div class="col-md-8">


            <table class="table">

                <thead>
                    <tr>
                        <td>Id</td>
                        <th>No. Empleado</th>
                        <th>Nombre</th>
                        <th>Apellido Paterno</th>
                        <th>Apellido Materno</th>
                        <th>Departamento</th>
                        <th>Puesto</th>
                        <th>Fecha de Nacimiento</th>
                        <th>Accciones</th>

                    </tr>
                </thead>

                <tbody>


                    <?php

                    $query = "SELECT * FROM personal";

                    $result_task = mysqli_query($conn, $query);

                    while ($row = mysqli_fetch_array($result_task)) { ?>

                        <tr>

                            <td> <?php echo $row['id'] ?> </td>
                            <td> <?php echo $row['NumeroEmpleado'] ?> </td>
                            <td> <?php echo $row['Nombre'] ?> </td>
                            <td> <?php echo $row['PrimerApellido'] ?> </td>
                            <td> <?php echo $row['SegundoApellido'] ?> </td>
                            <td> <?php echo $row['Area'] ?> </td>
                            <td> <?php echo $row['Puesto'] ?> </td>
                            <td> <?php echo $row['Nacimiento'] ?> </td>
                            <td>

                                <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning">
                                    <i class="fas fa-marker"> </i>
                                </a>




                            </td>
                            <td>
                                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">
                                    <i class="fa fa-trash-alt"></i>
                                </a>
                            </td>

                        </tr>

                    <?php }

                    ?>


                </tbody>

            </table>


        </div>

    </div>

</div>

<?php include("includes/Footer.php"); ?>
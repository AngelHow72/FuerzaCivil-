<?php
include("conection.php");


$numeroEmpleado = '';
$nombre = '';
$primerApellido = '';
$segundoApellido = '';
$area = '';
$puesto = '';
$nacimiento = '';

if (isset($_GET['id'])) {

    $id = $_GET['id'];
    $query = "SELECT * FROM personal WHERE id=$id";
    $result = mysqli_query($conn, $query);


    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
        $numeroEmpleado = $row['NumeroEmpleado'];
        $nombre = $row['Nombre'];
        $primerApellido = $row['PrimerApellido'];
        $segundoApellido = $row['SegundoApellido'];
        $area = $row['Area'];
        $puesto = $row['Puesto'];
        $nacimiento = $row['Nacimiento'];
    }
}

if (isset($_POST['update'])) {

    $id = $_GET['id'];

    $numeroEmpleado = $_POST['NumeroEmpleado'];
    $nombre = $_POST['Nombre'];
    $primerApellido = $_POST['PrimerApellido'];
    $segundoApellido = $_POST['SegundoApellido'];
    $area = $_POST['Area'];
    $puesto = $_POST['Puesto'];
    $nacimiento = $_POST['Nacimiento'];


    $query = "UPDATE personal set NumeroEmpleado = '$numeroEmpleado', Nombre = '$nombre' WHERE id=$id";
    

    mysqli_query($conn, $query);

    $_SESSION['message'] = 'Personal cambiado con exito';
    $_SESSION['message_type'] = 'warning';

    header("Location:index.php");

} else {
    $_SESSION['message'] = 'ERROR FATAL';
    $_SESSION['message_type'] = 'warning';
}

?>

<?php

include("includes/Header.php"); ?>

<div class="container p-4">
    <div class="row">
        <div class="card card-body">
           
        <form action="edit.php?id=<?php echo $_GET['id']; ?>"    method="POST">

                <div class="form-group">
                    <input type="text" name="NumeroEmpleado" value="<?php echo $numeroEmpleado; ?>" class="form-control" placeholder="Cambia el numero">
                </div>
                <br>

                <div class="form-group">
                    <input type="text" name="Nombre" value="<?php echo $nombre; ?>" class="form-control" placeholder="Cambia el Nombre">
                </div>
                <br>

                <div class="form-group">
                    <input type="text" name="PrimerApellido" value="<?php echo $primerApellido ?>" class="form-control" placeholder="Cambia el Apellido">
                </div>
                <br>
                
                <div class="form-group">
                    <input type="text" name="SegundoApellido" value="<?php echo $segundoApellido; ?>" class="form-control" placeholder="Cambia el Segundo Apellido">
                </div>
                <br>

                <div class="form-group">
                    <input type="text" name="Area" value="<?php echo $area; ?>" class="form-control" placeholder="Cambia la Area o Departamento">
                </div>
                <br>

                <div class="form-group">
                    <input type="text" name="Puesto" value="<?php echo $puesto; ?>" class="form-control" placeholder="Cambia el Puesto">
                </div>
                <br>

                <div class="form-group">
                    <input type="date" name="Nacimiento" value="<?php echo $nacimiento; ?>" class="form-control" placeholder="Cambia la fecha">
                </div>
                <br>

                <input type="submit" class="btn btn-success btn-block" name="update" value="Guardar">


            </form>

        </div>

    </div>

</div>


<?php
include("includes/Footer.php");

?>
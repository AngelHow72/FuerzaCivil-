<?php 

include("conection.php");


if(isset($_GET['id'])){

    $id = $_GET['id'];

    $query = "DELETE FROM personal WHERE id = $id";

    $result = mysqli_query($conn, $query);

    if(!$result) {

        die("Query failed");
    }

    $_SESSION['message'] = "Personal Removido con Exito";

    $_SESSION['message_type'] = 'danger';

    header("Location: index.php");

}

?>